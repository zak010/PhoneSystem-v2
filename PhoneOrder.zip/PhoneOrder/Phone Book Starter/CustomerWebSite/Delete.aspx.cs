﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Delete : System.Web.UI.Page
{
    public object OrderNo { get; private set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        //var to store the primary key value of the record to be deleted
        Int32 OrderNo;
    }

    //event handler for the yes button
    protected void btnYes_Click(object sender, EventArgs e)
    {
        //delete the record
        DeleteOrder();
        //redirect back to the main page
        Response.Redirect("Default.aspx");
    }

    protected void btnNo_Click(object sender, EventArgs e)
    {
        //redirect to the main menu
        Response.Redirect("Default.aspx");
    }
    void DeleteOrder()
    {
        //function to delete the selected record
        //create a new instance of the address book
        clsOrderCollection OrderBook = new clsOrderCollection();
        //find the record to delete
        OrderBook.ThisOrder.Find(OrderNo);
        //delete the record
        OrderBook.Delete();
    }
}