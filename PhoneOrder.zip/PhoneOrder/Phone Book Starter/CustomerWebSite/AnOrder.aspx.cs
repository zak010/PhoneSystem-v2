﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AnAddress : System.Web.UI.Page
{
    //variable to store the primary key with the page level scope
    Int32 OrderNo;

    public object txtManufacturerNo { get; private set; }

    //event handler for the page load event
    protected void Page_Load(object sender, EventArgs e)
    {
        //get the number of the address to be prosessed
        OrderNo = Convert.ToInt32(Session["OrderNo"]);
        if (IsPostBack == false)
        {
            //populate the list of brands
            DisplayBrands();
            //if this is not a new record
            if (OrderNo != -1)
            {
                //display the current data for the record
                DisplayOrder();
            }
        }
    }


    protected void btnOK_Click(object sender, EventArgs e)
    {
        //add the new record
        Add();
        //all done so redirect back to the main page
        Response.Redirect("Default.aspx");
        //create a new instance of clsOrder
        clsOrder AnOrder = new clsOrder();
        //catch the CustomerNo
        string CustomerNo = txtCustomerNo.Text;
        //catch the brand
        string Brand = ddlBrand.Text;
        //catch the Model
        string Model = txtModel.Text;
        //catch the Manufacturer
        string Manufacturer = txtManufacturer.Text;
        //catch the price 
        string Price = txtPrice.Text;
        //catch the date added
        string DateAdded = txtDateAdded.Text;
        //validate the data
        Error = AnOrder.Valid(CustomerNo, Brand, Model, Manufacturer, Price, DateAdded);
        if (Error == "")
        {
            //catch the CustomerNo
            AnOrder.CustomerNo = CustomerNo;
            //catch the brand
            AnOrder.Brand = Brand;
            //catch the Model
            AnOrder.Model = Model;
            //catch the Manufacturer
            AnOrder.Manufacturer = Manufacturer;
            //catch the price 
            AnOrder.Price = Price;
            //catch the date added
            AnOrder.DateAdded = DateAdded;
            //store the order in the session object
            Session["AnOrder"] = AnOrder;
            //redirect to the viewer page
            Response.Redirect("OrderViewer.aspx");
        }
        else
        {
            //display the error message
            lblError.Text = Error;
        }
        if (OrderNo == -1)
        {
            //add the new record 
            Add();
        }
        else
        {
            //update the record
            Update();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //redirect to the main menu
        Response.Redirect("Default.aspx");
    }
    //function for the populating the brand drop down list
    void DisplayBrands()
    {
        //create an instance of the brand collection
        ClassLibrary.clsBrandCollection Brands = new ClassLibrary.clsBrandCollection();
        //set the data source to the list of brands in the collection
        ddlBrand.DataSource = Brands.AllBrands;
        //set the primary key
        ddlBrand.DataValueField = "BrandNo";
        //set the data field to display the county name
        ddlBrand.DataTextField = "Brand";
        //bind the data to the list
        ddlBrand.DataBind();
    }

    protected void btnFind_Click(object sender, EventArgs e)
    {
        //create an instance of the order class
        clsOrder AnOrder = new clsOrder();
        //variable to store the primary key
        Int32 OrderNo;
        //variable to store the result of the find operation
        Boolean Found = false;
        //get the primary key entered by the user
        OrderNo = Convert.ToInt32(txtOrderNo.Text);
        //find the record
        Found = AnOrder.Find(OrderNo);
        //if found
        if (Found == true)
        {
            //display the values of the properties in the form
            txtOrderNo.Text = AnOrder.OrderNo;
            txtCustomerNo.Text = AnOrder.CustomerNo;
            ddlBrand.Text = AnOrder.Brand.ToString();
            txtModel.Text = AnOrder.Model;
            txtManufacturer.Text = AnOrder.Manufacturer;
            txtPrice.Text = AnOrder.Text;
            txtDateAdded.Text = AnOrder.DateAdded.ToString();
        }
    }
    //function for adding new records
    void Add()
    {
        //create an instance of the  of the order book
        clsOrderCollection OrderBook = new clsOrderCollection();
        //validate the data on the web form
        String Error = OrderBook.ThisOrder.Valid(txtCustomerNo.Text, txtModel.Text, txtManufacturer.Text, txtPrice, Text, txtDateAdded.Text);
        //if the data is OK then add it to the onject
        if (Error == "")
        {
            //get the data entered by the user
            OrderBook.ThisOrder.CustomerNo = txtCustomerNo.Text;
            OrderBook.ThisOrder.Model = txtModel.Text;
            OrderBook.ThisOrder.Manufacturer = txtManufacturer.Text;
            OrderBook.ThisOrder.Price = txtPrice.Text;
            OrderBook.ThisOrder.DateAdded = Convert.ToDateTime(txtDateAdded.Text);
            OrderBook.ThisOrder.Active = chkActive.Checked;
            OrderBook.ThisOrder.Brand = Convert.ToString(ddlBrand.SelectedValue);
            //add the record
            OrderBook.Add();
            //all done so redirect back to the main page
            Response.Redirect("Default.aspx");
        }
        else
        {
            //report and error
            lblError.Text = "There were problems with the data entered" + Error;
        }
    }
    //function for updating records
    void Update()
    {
        //create an instance of the order book
        ClassLibrary.clsOrderCollection OrderBook = new ClassLibrary.clsOrderCollection();
        //validate the data on the web form
        String Error = OrderBook.ThisOrder.Valid(txtCustomerNo.Text, txtModel.Text, txtManufacturer.Text, txtPrice, Text, txtDateAdded.Text);
        //if the data is OK then add it to the onject
        if (Error == "")
        {
            //get the data entered by the user
            OrderBook.ThisOrder.CustomerNo = txtCustomerNo.Text;
            OrderBook.ThisOrder.Model = txtModel.Text;
            OrderBook.ThisOrder.Manufacturer = txtManufacturer.Text;
            OrderBook.ThisOrder.Price = txtPrice.Text;
            OrderBook.ThisOrder.DateAdded = Convert.ToDateTime(txtDateAdded.Text);
            OrderBook.ThisOrder.Active = chkActive.Checked;
            OrderBook.ThisOrder.Brand = Convert.ToString(ddlBrand.SelectedValue);
            //Update the record
            OrderBook.Update();
            //all done so redirect back to the main page
            Response.Redirect("Default.aspx");
        }
        else
        {
            //report and error
            lblError.Text = "There were problems with the data entered" + Error;
        }
    }
    void DisplayOrder()
    {
        //create an instance of the order book
        clsOrderCollection OrderBook = new clsOrderCollection();
        //find the record to update
        OrderBook.ThisOrder.Find(OrderNo);
        //display the data for this record
        txtCustomerNo.Text = OrderBook.ThisOrder.CustomerNo;
        txtModel.Text = OrderBook.ThisOrder.Model;
        txtManufacturerNo.Text = OrderBook.ThisOrder.Manufacturer;
        txtPrice.Text = OrderBook.ThisOrder.Price;
        txtDateAdded.Text = OrderBook.ThisOrder.DateAdded.ToString();
        chkActive.Checked = OrderBook.ThisOrder.Active;
        ddlBrand.SelectedValue = OrderBook.ThisOrder.Brand.ToString();
    }
    void PopulateArray(clsDataConnection DB)
    {
        //populates the array list based on the data table in the parameter DB
        //var for the index
        Int32 Index = 0;
        //var to store the record count
        Int32 RecordCount;
        //get the count of records
        RecordCount = DB.Count;
        //clear the private array list
        mOrderList = new List<clsOrder>();
        //while there are records to process
        while (Index < RecordCount)
        {
            //create a blank Order
            clsOrder AnOrder = new clsOrder();
            //read in the fields from the current record
            AnOrder.Active = Convert.ToBoolean(DB.DataTable.Rows[Index]["Active"]);
            AnOrder.OrderNo = Convert.ToInt32(DB.DataTable.Rows[Index]["OrderNo"]);
            AnOrder.CustomerNo = Convert.ToString(DB.DataTable.Rows[Index]["CustomerNo"]);
            AnOrder.DateAdded = Convert.ToDateTime(DB.DataTable.Rows[Index]["DateAdded"]);
            AnOrder.Brand = Convert.ToString(DB.DataTable.Rows[Index]["Brand"]);
            AnOrder.Model = Convert.ToString(DB.DataTable.Rows[Index]["Model"]);
            AnOrder.Manufacturer = Convert.ToString(DB.DataTable.Rows[Index]["Manufacturer"]);
            AnOrder.Price = Convert.ToString(DB.DataTable.Rows[Index]["Price"]);
            //add the record to the private data member
            mOrderList.Add(AnOrder);
            //point at the next record
            Index++;
        }
    }
}

internal class clsOrder
{
    internal bool Active;

    public clsOrder()
    {
    }

    public string OrderNo { get; internal set; }
    public string CustomerNo { get; internal set; }
    public object Brand { get; internal set; }
    public string Model { get; internal set; }
    public string Manufacturer { get; internal set; }
    public string Text { get; internal set; }
    public object DateAdded { get; internal set; }
    public string Price { get; internal set; }

    internal bool Find(int orderNo)
    {
        throw new NotImplementedException();
    }

    internal EventHandler Valid(string customerNo, string brand, string model, string manufacturer, string price, string dateAdded)
    {
        throw new NotImplementedException();
    }
}