﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary;

public partial class AModel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnOK_Click(object sender, EventArgs e)
    {
        //create an instance of the class library
        clsModel AModel = new clsModel();
        //declare a variable to store any error messages
        string Error;
        //declare a variable to capture user input from the page
        string ModelName;
        //read in the date from the interface
        ModelName = txtModel.Text;
        //validate the data using the classes validation method
        Error = AModel.Valid(ModelName);
        //display an error message if there is one
        lblError.Text = Error;
    }
}