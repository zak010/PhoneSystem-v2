﻿
Partial Class AddressViewer
    Inherits System.Web.UI.Page

End Class
