﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLibrary;
using System;
using System.Collections.Generic;

namespace TestProject
{
    [TestClass]
    public class tstManufacturerCollection
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsManufacturerCollection AllManufacturers = new clsManufacturerCollection();
            //test to see that it exists
            Assert.IsNotNull(AllManufacturers);
        }
        [TestMethod]
        public void CountPropertyOK()
        {
            //create an instance of the class we want to create
            clsManufacturerCollection AllManufacturers = new clsManufacturerCollection();
            //create some test data to assign to the property
            Int32 SomeCount = 2;
            //assign the data to the property
            AllManufacturers.Count = SomeCount;
            //test to see that the two values are the same
            Assert.AreEqual(AllManufacturers.Count, SomeCount);
        }
        [TestMethod]
        public void AllManufacturersOK()
        {
            //create an instance of the class we want to create
            clsManufacturerCollection Manufacturers = new clsManufacturerCollection();
            //create some test data to assign to the property
            //in this case the data needs to be a list of objects
            List<clsManufacturer> TestList = new List<clsManufacturer>();
            //add an item to the list
            //create the item of test data
            clsManufacturer TestItem = new clsManufacturer();
            //set its properties
            TestItem.ManufacturerNo = 1;
            TestItem.Manufacturer = "Apple";
            //add the item to the test list
            TestList.Add(TestItem);
            //assign the data to the property
            Manufacturers.AllManufacturers = TestList;
            //test to see that the two values are the same
            Assert.AreEqual(Manufacturers.AllManufacturers, TestList);
        }
        //[TestMethod]
        //public void TwoCountiesPresent()
        //{
        //    //create an instance of the class we want to create
        //    clsManufacturerCollection Manufacturers = new clsManufacturerCollection();
        //    //test to see that the two values are the same
        //    Assert.AreEqual(Manufacturers.Count, 2);
        //}
        public class clsManufacturerCollection
        {
            private List<clsManufacturer> allManufacturers;
            private List<clsManufacturer> mAllManufacturers;

            //publc property for Count
            public int Count
            {
                get
                {
                    //return the count property of the private list
                    return AllManufacturers.Count;
                }
                set
                {
                    //we will look at this in a moment
                }
            }
            //public property for all manufactureres
            public List<clsManufacturer> AllManufacturers
            {
                //getter send data to requesting code
                get
                {
                    //return the private data member
                    return mAllManufacturers;
                }
                //setter accepts data from other objects
                set
                {
                    //assign the incoming value to the private data member
                    mAllManufacturers = value;
                }
            }
            //public constructor for the class
            public clsManufacturerCollection()
            {
                //create an instance of the Manufacturer class to store a Manufacturer
                clsManufacturer AManufacturer = new clsManufacturer();
                //set the Manufacturer to Apple
                AManufacturer.Manufacturer = "Manufacturer";
                //add the Manufacturer to the private lists of Manufacturers
                AllManufacturers.Add(AManufacturer);
                //re initialise the AManufacturer object to accept a new item
                AManufacturer = new clsManufacturer();
                //set the county to Samsung
                AManufacturer.Manufacturer = "Samsung";
                //add the second Manufacturer to the private list of Manufacturers
                AllManufacturers.Add(AManufacturer);
                AllManufacturers = allManufacturers;
                //the private list now contains two Manufacturers
            }
        }
    }
}