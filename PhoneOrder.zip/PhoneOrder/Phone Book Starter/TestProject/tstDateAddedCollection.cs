﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace TestProject
{
    [TestClass]
    public class tstDateAddedCollection
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsDateAddedCollection AllDateAddeds = new clsDateAddedCollection();
            //test to see that it exists
            Assert.IsNotNull(AllDateAddeds);
        }
        [TestMethod]
        public void CountPropertyOK()
        {
            //create an instance of the class we want to create
            clsDateAddedCollection AllDateAddeds = new clsDateAddedCollection();
            //create some test data to assign to the property
            Int32 SomeCount = 2;
            //assign the data to the property
            AllDateAddeds.Count = SomeCount;
            //test to see that the two values are the same
            Assert.AreEqual(AllDateAddeds.Count, SomeCount);
        }
        [TestMethod]
        public void AllDateAddedsOK()
        {
            //create an instance of the class we want to create
            clsDateAddedCollection DateAddeds = new clsDateAddedCollection();
            //create some test data to assign to the property
            //in this case the data needs to be a list of objects
            List<clsDateAdded> TestList = new List<clsDateAdded>();
            //add an item to the list
            //create the item of test data
            clsDateAdded TestItem = new clsDateAdded();
            //set its properties
            TestItem.DateAddedNo = 1;
            TestItem.DateAdded = "19/05/2019";
            //add the item to the test list
            TestList.Add(TestItem);
            //assign the data to the property
            DateAddeds.AllDateAddeds = TestList;
            //test to see that the two values are the same
            Assert.AreEqual(DateAddeds.AllDateAddeds, TestList);
        }

        public class clsDateAddedCollection
        {
            //private data memeber for the allCounties list
            private List<clsDateAdded> mAllDateAddeds = new List<clsDateAdded>();
            //publc property for Count
            public int Count
            {
                get
                {
                    //return the count property of the private list
                    return mAllDateAddeds.Count;
                }
                set
                {
                    //we will look at this in a moment
                }
            }
            //public property for allDateAddeds
            public List<clsDateAdded> AllDateAddeds
            {
                //getter send data to requesting code
                get
                {
                    //return the private data member
                    return mAllDateAddeds;
                }
                //setter accepts data from other objects
                set
                {
                    //assign the incoming value to the private data member
                    mAllDateAddeds = value;
                }
            }
            //public constructor for the class
            public clsDateAddedCollection()
            {
                //create an instance of the DateAdded class to store a DateAdded
                clsDateAdded ADateAdded = new clsDateAdded();
                //set the DateAdded to Apple
                ADateAdded.DateAdded = "DateAdded";
                //add the DateAdded to the private lists of DateAddeds
                mAllDateAddeds.Add(ADateAdded);
                //re initialise the ADateAdded object to accept a new item
                ADateAdded = new clsDateAdded();
                //set the county to Samsung
                ADateAdded.DateAdded = "20/10/2020";
                //add the second DateAdded to the private list of DateAddeds
                mAllDateAddeds.Add(ADateAdded);
                //the private list now contains two DateAddeds
            }
        }
    }
}
