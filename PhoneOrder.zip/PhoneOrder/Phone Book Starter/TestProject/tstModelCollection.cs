﻿using System;
using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace TestProject
{
    [TestClass]
    public class tstModelCollection
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsModelCollection AllModels = new clsModelCollection();
            //test to see that it exists
            Assert.IsNotNull(AllModels);
        }
        [TestMethod]
        public void CountPropertyOK()
        {
            //create an instance of the class we want to create
            clsModelCollection AllModels = new clsModelCollection();
            //create some test data to assign to the property
            Int32 SomeCount = 2;
            //assign the data to the property
            AllModels.Count = SomeCount;
            //test to see that the two values are the same
            Assert.AreEqual(AllModels.Count, SomeCount);
        }
        [TestMethod]
        public void AllModelsOK()
        {
            //create an instance of the class we want to create
            clsModelCollection Models = new clsModelCollection();
            //create some test data to assign to the property
            //in this case the data needs to be a list of objects
            List<clsModel> TestList = new List<clsModel>();
            //add an item to the list
            //create the item of test data
            clsModel TestItem = new clsModel();
            //set its properties
            TestItem.ModelNo = 1;
            TestItem.Model = "11";
            //add the item to the test list
            TestList.Add(TestItem);
            //assign the data to the property
            Models.AllModels = TestList;
            //test to see that the two values are the same
            Assert.AreEqual(Models.AllModels, TestList);
        }
        //[TestMethod]
        //public void TwoCountiesPresent()
        //{
        //    //create an instance of the class we want to create
        //    clsModelCollection Models = new clsModelCollection();
        //    //test to see that the two values are the same
        //    Assert.AreEqual(Models.Count, 2);
        //}
        public class clsModelCollection
        {
            //private data memeber for the allCounties list
            private List<clsModel> mAllModels = new List<clsModel>();
            //publc property for Count
            public int Count
            {
                get
                {
                    //return the count property of the private list
                    return mAllModels.Count;
                }
                set
                {
                    //we will look at this in a moment
                }
            }
            //public property for allModels
            public List<clsModel> AllModels
            {
                //getter send data to requesting code
                get
                {
                    //return the private data member
                    return mAllModels;
                }
                //setter accepts data from other objects
                set
                {
                    //assign the incoming value to the private data member
                    mAllModels = value;
                }
            }
            //public constructor for the class
            public clsModelCollection()
            {
                //create an instance of the Model class to store a Model
                clsModel AModel = new clsModel();
                //set the Model to Apple
                AModel.Model = "Model";
                //add the Model to the private lists of Models
                mAllModels.Add(AModel);
                //re initialise the AModel object to accept a new item
                AModel = new clsModel();
                //set the county to Samsung
                AModel.Model = "Galaxy";
                //add the second Model to the private list of Models
                mAllModels.Add(AModel);
                //the private list now contains two Models
            }
        }
    }
}