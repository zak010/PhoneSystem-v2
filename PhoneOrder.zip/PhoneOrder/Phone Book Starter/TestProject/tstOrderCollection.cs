﻿using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace TestProject
{
    [TestClass]
    public class tstOrderCollection
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection AllOrders = new clsOrderCollection();
            //test to see that it exists
            Assert.IsNotNull(AllOrders);
        }
        [TestMethod]
        public void OrderListOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection AllOrders = new clsOrderCollection();
            //create some test data to assign to the property
            //in this case the data needs to be a list of objects
            List<clsOrder> TestList = new List<clsOrder>();
            //add an item to the list
            //create the item of test data
            clsOrder TestItem = new clsOrder();
            //set its properties
            TestItem.Active = true;
            TestItem.OrderNo = 1;
            TestItem.CustomerNo = 1;
            TestItem.DateAdded = DateTime.Now.Date;
            TestItem.Brand = "some brand";
            TestItem.Model = "some model";
            TestItem.Manufacturer = "some manufacturer";
            TestItem.Price = "some price";
            //add the item to the test list
            TestList.Add(TestItem);
            //assign the data to the property
            AllOrders.OrderList = TestList;
            //test to see that the two values are the same
            Assert.AreEqual(AllOrders.OrderList, TestList);
        }
        [TestMethod]
        public void CountPropertyOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection AllOrders = new clsOrderCollection();
            //create some test data to assign to the property
            Int32 SomeCount = 2;
            //assign the data to the property
            AllOrders.Count = SomeCount;
            //test to see that the two values are the same
            Assert.AreEqual(AllOrders.Count, SomeCount);
        }
        [TestMethod]
        public void ThisOrderPropertyOK()
        {
             //create an instance of the class we want to create
            clsOrderCollection AllOrders = new clsOrderCollection();
            //create some test data to assign to the property
            clsOrder TestOrder = new clsOrder();
            //set the properties of the test object
            TestOrder.Active = true;
            TestOrder.OrderNo = 1;
            TestOrder.CustomerNo = 1;
            TestOrder.DateAdded = DateTime.Now.Date;
            TestOrder.Brand = "some brand";
            TestOrder.Model = "some model";
            TestOrder.Manufacturer = "some manufacturer";
            TestOrder.Price = "£1000";
            //assign the data to the property
            AllOrders.ThisOrder = TestOrder;
            //test to see that the two values are the same
            Assert.AreEqual(AllOrders.ThisOrder, TestOrder);
        }
        [TestMethod]
        public void ListAndCountOK()
        {
            //create an instance of the class we want to create
            clsOrderCollection AllOrders = new clsOrderCollection();
            //create some test data to assign to the property
            //in this case the data needs to be a list of objects
            List<clsOrder> TestList = new List<clsOrder>();
            //add an item to the list
            //create the item of test data
            clsOrder TestItem = new clsOrder();
            //set its properties
            TestItem.Active = true;
            TestItem.OrderNo = 1;
            TestItem.CustomerNo = 1;
            TestItem.DateAdded = DateTime.Now.Date;
            TestItem.Brand = "some brand";
            TestItem.Model = "some model";
            TestItem.Manufacturer = "some manufacturer";
            TestItem.Price = "£500";
            //add the item to the test list
            TestList.Add(TestItem);
            //assign the data to the property
            AllOrders.OrderList = TestList;
            //test to see that the two values are the same
            Assert.AreEqual(AllOrders.OrderList, TestList);
        }
        [TestMethod]
        public void TwoRecordsPresent()
        {
            //create an instance of the class we ant to create
            clsOrderCollection AllOrders = new clsOrderCollection();
            //test to see that the two values are the same
            Assert.AreEqual(AllOrders.Count, 2);
        }
        //constructor for the class
        public clsOrderCollection()
        {
            //create the item of test data
            clsOrder TestItem = new clsOrder
            {
                //set its properties
                Active = true,
                OrderNo = 1,
                CustomerNo = 1,
                DateAdded = DateTime.Now.Date,
                Brand = "some brand",
                Model = "some model",
                Manufacturer = "some manufacturer",
                Price = "£500"
            };
            //add the item to the test list
            mOrderList.Add(TestItem);
            //re initialise the object for some new data
            TestItem = new clsOrder();
            //set its properties
            TestItem.Active = true;
            TestItem.OrderNo = 2;
            TestItem.CustomerNo = 2;
            TestItem.DateAdded = DateTime.Now.Date;
            TestItem.Brand = "some brand";
            TestItem.Model = "some model";
            TestItem.Manufacturer = "some manufacturer";
            TestItem.Price = "£500";
            //add the item to the test list
            mOrderList.Add(TestItem);
        }
        [TestMethod]
        public void ReportByBrandMethodOK()
        {
            //create an instance of the class containign unfiltered results
            clsOrderCollection AllOrders = new clsOrderCollection();
            //create an instance of the filtered data
            clsOrderCollection FilteredOrders = new clsOrderCollection();
            //apply a blank string
            FilteredOrders.ReportByBrand("");
            //Test to see that the two values are the same
            Assert.AreEqual(AllOrders.Count, FilteredOrders.Count);
        }

        [TestMethod]
        public void ReportByBrandNoneFound()
        {
            //create an instance of the filtered data
            clsOrderCollection FilteredOrders = new clsOrderCollection();
            //apply a brand that doesn't exist
            FilteredOrders.ReportByBrand("xxxxxxxxxx");
            //test to see that there are no records
            Assert.AreEqual(0, FilteredOrders.Count);
        }
        [TestMethod]
        public void ReportByBrandTestDataFound()
        {
            //create an instance of the filtered data
            clsOrderCollection FilteredOrders = new clsOrderCollection();
            //var to store outcome
            Boolean OK = true;
            //apply a brand that doesn't exist
            FilteredOrders.ReportByBrand("xxxxxxxxxx");
            //check that the correct number of records are found
            if (FilteredOrders.Count == 2)
            {
                //check that the first record is ID 1
                if (FilteredOrders.OrderList[0].OrderNo != 1)
                {
                    OK = false;
                }
                //check that the first record is ID 2
                if (FilteredOrders.OrderList[0].OrderNo != 2)
                {
                    OK = false;
                }
            }
            else
            {
                OK = false;
            }
            //test to see that there are no records
            Assert.IsTrue(OK);
        }
    }
}
