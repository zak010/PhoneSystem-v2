﻿using System;
using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace TestProject
{
    [TestClass]
    public class tstBrandCollection
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsBrandCollection AllBrands = new clsBrandCollection();
            //test to see that it exists
            Assert.IsNotNull(AllBrands);
        }
        [TestMethod]
        public void CountPropertyOK()
        {
            //create an instance of the class we want to create
            clsBrandCollection AllBrands = new clsBrandCollection();
            //create some test data to assign to the property
            Int32 SomeCount = 2;
            //assign the data to the property
            AllBrands.Count = SomeCount;
            //test to see that the two values are the same
            Assert.AreEqual(AllBrands.Count, SomeCount);
        }
        [TestMethod]
        public void AllBrandsOK()
        {
            //create an instance of the class we want to create
            clsBrandCollection Brands = new clsBrandCollection();
            //create some test data to assign to the property
            //in this case the data needs to be a list of objects
            List<clsBrand> TestList = new List<clsBrand>();
            //add an item to the list
            //create the item of test data
            clsBrand TestItem = new clsBrand();
            //set its properties
            TestItem.BrandNo = 1;
            TestItem.Brand = "Apple";
            //add the item to the test list
            TestList.Add(TestItem);
            //assign the data to the property
            Brands.AllBrands = TestList;
            //test to see that the two values are the same
            Assert.AreEqual(Brands.AllBrands, TestList);
        }
        //[TestMethod]
        //public void TwoCountiesPresent()
        //{
        //    //create an instance of the class we want to create
        //    clsBrandCollection Brands = new clsBrandCollection();
        //    //test to see that the two values are the same
        //    Assert.AreEqual(Brands.Count, 2);
        //}
        public class clsBrandCollection
        {
            //private data memeber for the allCounties list
            private List<clsBrand> mAllBrands = new List<clsBrand>();
            //publc property for Count
            public int Count
            {
                get
                {
                    //return the count property of the private list
                    return mAllBrands.Count;
                }
                set
                {
                    //we will look at this in a moment
                }
            }
            //public property for allBrands
            public List<clsBrand> AllBrands
            {
                //getter send data to requesting code
                get
                {
                    //return the private data member
                    return mAllBrands;
                }
                //setter accepts data from other objects
                set
                {
                    //assign the incoming value to the private data member
                    mAllBrands = value;
                }
            }
            //public constructor for the class
            public clsBrandCollection()
            {
                //create an instance of the brand class to store a brand
                clsBrand ABrand = new clsBrand();
                //set the Brand to Apple
                ABrand.Brand = "Brand";
                //add the brand to the private lists of brands
                mAllBrands.Add(ABrand);
                //re initialise the ABrand object to accept a new item
                ABrand = new clsBrand();
                //set the county to Samsung
                ABrand.Brand = "Samsung";
                //add the second brand to the private list of brands
                mAllBrands.Add(ABrand);
                //the private list now contains two brands
            }
        }
    }
}
