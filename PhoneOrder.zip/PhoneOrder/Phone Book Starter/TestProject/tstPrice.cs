﻿using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    [TestMethod]
    public void InstanceOK()
    {
        //create an instance of the class we want to create
        clsOrder AOrder = new clsOrder();
        //test to see that it exists
        Assert.IsNotNull(AOrder);
    }
    [TestMethod]
    public void PricePropertyOK()
    {
        //create an instance of the class we want to create
        clsOrder AOrder = new clsOrder();
        //create some test data to assign to the property
        string SomePrice = "£500";
        //assign the data to the property
        AOrder.Price = SomePrice;
        //test to see that the two values are the same
        Assert.AreEqual(AOrder.Price, SomePrice);
    }
    [TestMethod]
    public void ValidMethodOK()
    {
        //create an instance of the class we want to create
        clsOrder AOrder = new clsOrder();
        //create a string variable to store the result of the validation
        String Error = "";
        //create some test data to test the method
        string SomePrice = "£1000";
        //invoke the method
        Error = AOrder.Valid(SomePrice);
        //test to see that the result is OK i.e there was no error message returned
        Assert.AreEqual(Error, "");
    }
}
