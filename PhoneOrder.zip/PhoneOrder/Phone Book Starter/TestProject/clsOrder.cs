﻿using System;

namespace ClassLibrary
{
    public class clsOrder
    {
        //private data member for the order no property
        private Int32 mOrderNo;
        //OrderNo public property
        public Int32 OrderNo
        {
            get
            {
                //this line of code sends data out of the property
                return mOrderNo;
            }
            set
            {
                //this line of code allows data into the property
                mOrderNo = value;
            }
        }

        public bool Find(int orderNo)
        {
            //set the private data members to the test data value
            mOrderNo = 21;
            mBrand = "abc";
            mModel = "Test Model";
            mManufacturer = "Test Manufacturer";
            mPrice = "Test Price";
            mCustomerNo = 1;
            mDateAdded = Convert.ToDateTime("16/9/2015");
            mActive = true;

            //always return true
            return true;
        }

        //CustomerNo private member variable
        private Int32 mCustomerNo;
        //OrderNo public property
        public int CustomerNo
        {
            get
            {
                //this line of code sends data out of the property
                return mCustomerNo;
            }
            set
            {
                //this line of code allows data into the property
                mCustomerNo = value;
            }
        }

        internal string Valid(string somePrice)
        {
            throw new NotImplementedException();
        }

        internal int Valid(int someCustomerNo)
        {
            throw new NotImplementedException();
        }

        internal string Valid(DateTime someDateAdded)
        {
            throw new NotImplementedException();
        }

        //Brand private member variable
        private String mBrand;
        //OrderNo public property
        public String Brand
        {
            get
            {
                //this line of code sends data out of the property
                return mBrand;
            }
            set
            {
                //this line of code allows data into the property
                mBrand = value;
            }
        }

        //Model private member variable
        private String mModel;
        //OrderNo public property
        public String Model
        {
            get
            {
                //this line of code sends data out of the property
                return mModel;
            }
            set
            {
                //this line of code allows data into the property
                mModel = value;
            }
        }

        //Manufacturer private member variable
        private String mManufacturer;
        //OrderNo public property
        public String Manufacturer
        {
            get
            {
                //this line of code sends data out of the property
                return mManufacturer;
            }
            set
            {
                //this line of code allows data into the property
                mManufacturer = value;
            }
        }

        //Price private member variable
        private String mPrice;
        //OrderNo public property
        public String Price
        {
            get
            {
                //this line of code sends data out of the property
                return mPrice;
            }
            set
            {
                //this line of code allows data into the property
                mPrice = value;
            }
        }

        //dateAdded private member variable
        private DateTime mDateAdded;

        //dateAdded public property
        public DateTime DateAdded
        {
            get
            {
                //this line of code sends data out of the property
                return mDateAdded;
            }
            set
            {
                //this line of code allows data into the property
                mDateAdded = value;
            }
        }

        //Active private member variable
        private Boolean mActive;

        //dateAdded public property
        public Boolean Active
        {
            get
            {
                //this line of code sends data out of the property
                return mActive;
            }
            set
            {
                //this line of code allows data into the property
                mActive = value;
            }
        }
        public object mThisOrder { get; private set; }

        public int Add()
        {
            //adds a new record to the database based on the values of thisOrder
            //connect to the database
            clsDataConnection DB = new clsDataConnection();
            //set the parameters for the stored procedure
            DB.AddParameter("@CustomerNo", mThisOrder.CustomerNo);
            DB.AddParameter("@Brand", mThisOrder.Brand);
            DB.AddParameter("@Model", mThisOrder.Model);
            DB.AddParameter("@Manfacturer", mThisOrder.Manufacturer);
            DB.AddParameter("@Price", mThisOrder.Price);
            DB.AddParameter("@DateAdded", mThisOrder.DateAdded);
            DB.AddParameter("@Active", mThisOrder.Active);
            //execute the query returning the primary key value
            return DB.Execute("sproc_tblOrder_Insert");
        }
        public void Delete()
        {
            //deletes the record pointed to by thisOrder
            //connect to the database
            clsDataConnection DB = new clsDataConnection();
            //set the parameters for the stored procedure
            DB.AddParameter("@OrderNo", mThisOrder.OrderNo);
            //execute the stored procedure
            DB.Execute("sproc_tblOrder_Delete");
        }
        public int Update()
        {
            //update an existing record based on the values of ThisOrder
            //connect to the database
            clsDataConnection DB = new clsDataConnection();
            //set the parameters for the stored procedure
            DB.AddParameter("@CustomerNo", mThisOrder.CustomerNo);
            DB.AddParameter("@Brand", mThisOrder.Brand);
            DB.AddParameter("@Model", mThisOrder.Model);
            DB.AddParameter("@Manfacturer", mThisOrder.Manufacturer);
            DB.AddParameter("@Price", mThisOrder.Price);
            DB.AddParameter("@DateAdded", mThisOrder.DateAdded);
            DB.AddParameter("@Active", mThisOrder.Active);
            //execute the query returning the primary key value
            return DB.Execute("sproc_tblOrder_Update");
        }
    }
}
