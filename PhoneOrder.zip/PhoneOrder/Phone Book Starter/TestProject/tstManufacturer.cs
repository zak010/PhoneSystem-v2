﻿using System;
using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestProject
{
    [TestClass]
    public class tstManufacturer
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //test to see that it exists
            Assert.IsNotNull(AManufacturer);
        }
        [TestMethod]
        public void ManufacturerPropertyOK()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create some test data to assign to the property
            string SomeManufacturer = "Apple";
            //assign the data to the property
            AManufacturer.Manufacturer = SomeManufacturer;
            //test to see that the two values are the same
            Assert.AreEqual(AManufacturer.Manufacturer, SomeManufacturer);
        }
        [TestMethod]
        public void ValidMethodOK()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeManufacturer = "Apple";
            //invoke the method
            Error = AManufacturer.Valid(SomeManufacturer);
            //test to see that the result is OK i.e there was no error message returned
            Assert.AreEqual(Error, "");
        }
        public void ManufacturerMinLessOne()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeManufacturer = "";
            //invoke the method
            Error = AManufacturer.Valid(SomeManufacturer);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
        [TestMethod]
        public void ManufacturerMinBoundary()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeManufacturer = "a";
            //invoke the method
            Error = AManufacturer.Valid(SomeManufacturer);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ManufacturerMinPlusOne()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeManufacturer = "aa";
            //invoke the method
            Error = AManufacturer.Valid(SomeManufacturer);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ManufacturerMaxLessOne()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeManufacturer = "0123456789012345678";
            //invoke the method
            Error = AManufacturer.Valid(SomeManufacturer);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ManufacturerMaxBoundary()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeManufacturer = "01234567890123456789";
            //invoke the method
            Error = AManufacturer.Valid(SomeManufacturer);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ManufacturerMaxPlusOne()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeManufacturer = "012345678901234567890";
            //invoke the method
            Error = AManufacturer.Valid(SomeManufacturer);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }
        [TestMethod]
        public void ManufacturerMid()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeManufacturer = "0123456789";
            //invoke the method
            Error = AManufacturer.Valid(SomeManufacturer);
            //test to see that the result is ok i.e there should be an error message
            Assert.AreEqual(Error, "");
        }
        [TestMethod]
        public void ManufacturerExtremeMax()
        {
            //create an instance of the class we want to create
            clsManufacturer AManufacturer = new clsManufacturer();
            //create a string variable to store the result of the validation
            String Error = "";
            //create some test data to test the method
            string SomeManufacturer = "";
            //pad the string with characters
            SomeManufacturer = SomeManufacturer.PadRight(500, 'a');
            //invoke the method
            Error = AManufacturer.Valid(SomeManufacturer);
            //test to see that the result is not ok i.e there should be an error message
            Assert.AreNotEqual(Error, "");
        }

    }
}
