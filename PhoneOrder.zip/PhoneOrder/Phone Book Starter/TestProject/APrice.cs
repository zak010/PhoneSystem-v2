﻿namespace TestProject
{
    internal class APrice
    {
    }
}