﻿using System;

namespace ClassLibrary
{
    internal class clsManufacturer
    {
        public string Manufacturer { get; internal set; }
        public int ManufacturerNo { get; internal set; }

        public string Valid(string someManufacturer)
        {
            //string variable to store the error message
            string Error = "";
            //if the name of the county is more than 20 characters
            if (someManufacturer.Length > 20)
            {
                //return an error message
                Error = "The brand name cannot have more than 20 characters";
            }
            if (someManufacturer.Length == 0)
            {
                //return an error message
                Error = "The manufacturer name may not be blank!";
            }
            return Error;
        }

        internal bool Find(int orderNo)
        {
            throw new NotImplementedException();
        }
    }
}