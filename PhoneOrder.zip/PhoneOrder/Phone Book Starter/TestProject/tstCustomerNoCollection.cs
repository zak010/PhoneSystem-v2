﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    [TestClass]
    public class tstCustomerNoCollection
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
