﻿using ClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject
{
    [TestClass]
    public class tstCustomerNo
    {
        [TestMethod]
        public void InstanceOK()
        {
            //create an instance of the class we want to create
            clsOrder ACustomerNo = new clsOrder();
            //test to see that it exists
            Assert.IsNotNull(ACustomerNo);
        }
        [TestMethod]
        public void CustomerNoPropertyOK()
        {
            //create an instance of the class we want to create
            clsOrder AnOrder = new clsOrder();
            //create some test data to assign to the property
            Int32 TestData = 1;
            //create some test data
            AnOrder.CustomerNo = TestData;
            //test to see that the two values are the same
            Assert.AreEqual(AnOrder.CustomerNo, TestData);
        }
        [TestMethod]
        public void ValidMethodOK()
        {
            //create an instance of the class we want to create
            clsOrder ACustomerNo = new clsOrder();
            //create a string variable to store the result of the validation
            Int32 Error = 1;
            //create some test data to test the method
            int SomeCustomerNo = 1;
            //invoke the method
            Error = ACustomerNo.Valid(SomeCustomerNo);
            //test to see that the result is OK i.e there was no error message returned
            Assert.AreEqual(Error, "");
        }
    }
}
