﻿using ClassLibrary;
using System;

namespace TestProject
{
    internal class mOrderList
    {
        internal static void Add(clsOrder testItem)
        {
            throw new NotImplementedException();
        }
    }
}