﻿using System;

namespace ClassLibrary
{
    public class clsOrder
    {
        public int OrderNo { get; set; }

        public static implicit operator clsOrder(clsOrder v)
        {
            throw new NotImplementedException();
        }

        public static implicit operator clsOrder(clsOrder v)
        {
            throw new NotImplementedException();
        }

        public static implicit operator clsOrder(clsOrder v)
        {
            throw new NotImplementedException();
        }
    }
}