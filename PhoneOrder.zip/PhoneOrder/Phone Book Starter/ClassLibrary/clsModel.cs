﻿using System;

namespace ClassLibrary
{
    public class clsModel
    {
        public int ModelNo;

        public string Model { get; set; }

        public string Valid(string someModel)
        {
            //string variable to store the error message
            string Error = "";
            //if the name of the county is more than 20 characters
            if (someModel.Length > 20)
            {
                //return an error message
                Error = "The Model name cannot have more than 20 characters";
            }
            if (someModel.Length == 0)
            {
                //return an error message
                Error = "The Model name may not be blank!";
            }
            return Error;
        }

        public bool Find(int orderNo)
        {
            throw new NotImplementedException();
        }
    } 
}