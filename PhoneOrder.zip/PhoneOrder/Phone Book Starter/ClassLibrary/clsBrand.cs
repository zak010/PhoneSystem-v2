﻿using System;

namespace ClassLibrary
{
    public class clsBrand
    {
        public int BrandNo;

        public clsBrand()
        {
        }

        public string Brand { get; set; }

        public string Valid(string someBrand)
        {
            //string variable to store the error message
            string Error = "";
            //if the name of the county is more than 20 characters
            if (someBrand.Length > 20)
            {
                //return an error message
                Error = "The brand name cannot have more than 20 characters";
            }
            if (someBrand.Length == 0)
            {
                //return an error message
                Error = "The brand name may not be blank!";
            }
            return Error;
        }

        public bool Find(int addressNo)
        {
            throw new NotImplementedException();
        }
    }
}