﻿using System;

namespace ClassLibrary
{
    internal class clsDateAdded
    {
        public clsDateAdded()
        {
        }

        public DateTime DateAdded { get; internal set; }
        public int DateAddedNo { get; internal set; }

        internal string Valid(string someDateAdded)
        {
            throw new NotImplementedException();
        }

        internal string Valid(DateTime someDateAdded)
        {
            throw new NotImplementedException();
        }
    }
}