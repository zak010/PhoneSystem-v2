﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class clsPriceCollection
    {
    }
    //public constructor for the class
    public clsPriceCollection()
    {
        clsPrice APrice = new clsPrice();
        APrice.Price = "1000";
        mAllPrices.Add(APrice);
        APrice = new clsPrice();
        APrice.Price = "500";
        mAllPrices.Add(APrice);
    }

    //public constructor for the class
    public clsPriceCollection()
    {
        //create and instance of the dataconnection
        clsDataConnection DB = new clsDataConnection();
        //execute the stored procedure to get the list of data
        DB.Execute("sproc_tblPrice_SelectAll");
        //get the count of records
        Int32 RecordCount = DB.Count;
        //set up the index for the loop
        Int32 Index = 0;
        //while there are records to process 
        while (Index < RecordCount)
        {
            //create a new instance of the Brand class
            clsPrice APrice = new clsPrice();
            //get the brand name
            APrice.Price = DB.DataTable.Rows[Index]["Price"].ToString();
            //get the primary key
            APrice.PriceNo = Convert.ToInt32(DB.DataTable.Rows[Index]["PriceNo"]);
            //add the brand to the private data member
            mAllPrices.Add(APrice);
            //increment the index
            Index++;
        }
    }

    internal class mAllPrices
    {
        internal static void Add(clsPrice aPrice)
        {
            throw new NotImplementedException();
        }
    }
}
