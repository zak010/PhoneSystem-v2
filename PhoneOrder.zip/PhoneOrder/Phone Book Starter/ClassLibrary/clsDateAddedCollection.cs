﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class clsDateAddedCollection
    {
    }
    //public constructor for the class
    public clsDateAddedCollection()
    {
        clsDateAdded ADateAdded = new clsDateAdded();
        ADateAdded.DateAdded = "19/05/2019";
        mAllDateAddeds.Add(ADateAdded);
        ADateAdded = new clsDateAdded();
        ADateAdded.DateAdded = "20/10/2020";
        mAllDateAddeds.Add(ADateAdded);
    }

    //public constructor for the class
    public clsDateAddedCollection()
    {
        //create and instance of the dataconnection
        clsDataConnection DB = new clsDataConnection();
        //execute the stored procedure to get the list of data
        DB.Execute("sproc_tblDateAdded_SelectAll");
        //get the count of records
        Int32 RecordCount = DB.Count;
        //set up the index for the loop
        Int32 Index = 0;
        //while there are records to process 
        while (Index < RecordCount)
        {
            //create a new instance of the DateAdded class
            clsDateAdded ADateAdded = new clsDateAdded();
            //get the DateAdded name
            ADateAdded.DateAdded = DB.DataTable.Rows[Index]["DateAdded"].ToString();
            //get the primary key
            ADateAdded.DateAddedNo = Convert.ToDateTime(DB.DataTable.Rows[Index]["DateAddedNo"]);
            //add the DateAdded to the private data member
            mAllDateAddeds.Add(ADateAdded);
            //increment the index
            Index++;
        }
    }

    internal class mAllDateAddeds
    {
        internal static void Add(clsDateAdded aDateAdded)
        {
            throw new NotImplementedException();
        }
    }
}
