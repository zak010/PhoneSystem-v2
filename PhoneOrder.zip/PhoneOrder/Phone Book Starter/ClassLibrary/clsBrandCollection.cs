﻿using System;
using System.Collections.Generic;

namespace ClassLibrary
{
    public class clsBrandCollection
    {
        public int Count { get; set; }
        public List<clsBrand> AllBrands { get; set; }
    }

    //public constructor for the class
    public clsBrandCollection()
    {
        clsBrand ABrand = new clsBrand();
        ABrand.Brand = "Apple";
        mAllBrands.Add(ABrand);
        ABrand = new clsBrand();
        ABrand.Brand = "Samsung";
        mAllBrands.Add(ABrand);
    }

    //public constructor for the class
    public clsBrandCollection()
    {
        //create and instance of the dataconnection
        clsDataConnection DB = new clsDataConnection();
        //execute the stored procedure to get the list of data
        DB.Execute("sproc_tblBrand_SelectAll");
        //get the count of records
        Int32 RecordCount = DB.Count;
        //set up the index for the loop
        Int32 Index = 0;
        //while there are records to process 
        while (Index < RecordCount)
        {
            //create a new instance of the Brand class
            clsBrand ABrand = new clsBrand();
            //get the brand name
            ABrand.Brand = DB.DataTable.Rows[Index]["Brand"].ToString();
            //get the primary key
            ABrand.BrandNo = Convert.ToInt32(DB.DataTable.Rows[Index]["BrandNo"]);
            //add the brand to the private data member
            mAllBrands.Add(ABrand);
            //increment the index
            Index++;
        }
    }

    internal class mAllBrands
    {
        internal static void Add(clsBrand aBrand)
        {
            throw new NotImplementedException();
        }
    }
}