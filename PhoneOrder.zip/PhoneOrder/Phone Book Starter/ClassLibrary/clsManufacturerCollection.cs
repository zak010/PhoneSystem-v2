﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class clsManufacturerCollection
    {
        public int Count { get; set; }
        public List<clsManufacturer> AllManufacturers { get; set; }
    }

    //public constructor for the class
    public clsManufacturerCollection()
    {
        clsManufacturer AManufacturer = new clsManufacturer();
        AManufacturer.Manufacturer = "Apple";
        mAllManufacturers.Add(AManufacturer);
        AManufacturer = new clsManufacturer();
        AManufacturer.Manufacturer = "Samsung";
        mAllManufacturers.Add(AManufacturer);
    }

    internal class clsManufacturer
    {
        public clsManufacturer()
        {
        }
    }

    //public constructor for the class
    public clsManufacturerCollection()
    {
        //create and instance of the dataconnection
        clsDataConnection DB = new clsDataConnection();
        //execute the stored procedure to get the list of data
        DB.Execute("sproc_tblManufacturer_SelectAll");
        //get the count of records
        Int32 RecordCount = DB.Count;
        //set up the index for the loop
        Int32 Index = 0;
        //while there are records to process 
        while (Index < RecordCount)
        {
            //create a new instance of the Manufacturer class
            clsManufacturer AManufacturer = new clsManufacturer();
            //get the Manufacturer name
            AManufacturer.Manufacturer = DB.DataTable.Rows[Index]["Manufacturer"].ToString();
            //get the primary key
            AManufacturer.ManufacturerNo = Convert.ToInt32(DB.DataTable.Rows[Index]["ManufacturerNo"]);
            //add the Manufacturer to the private data member
            mAllManufacturers.Add(AManufacturer);
            //increment the index
            Index++;
        }
    }

    internal class mAllManufacturers
    {
        internal static void Add(clsManufacturer aManufacturer)
        {
            throw new NotImplementedException();
        }
    }
}