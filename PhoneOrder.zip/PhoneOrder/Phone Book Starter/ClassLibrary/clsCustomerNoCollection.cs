﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class clsCustomerNoCollection
    {
    }
    //public constructor for the class
    public clsCustomerNoCollection()
    {
        clsCustomerNo ACustomerNo = new clsCustomerNo();
        ACustomerNo.CustomerNo = "1";
        mAllCustomerNos.Add(ACustomerNo);
        ACustomerNo = new clsCustomerNo();
        ACustomerNo.CustomerNo = "5";
        mAllCustomerNos.Add(ACustomerNo);
    }

    //public constructor for the class
    public clsCustomerNoCollection()
    {
        //create and instance of the dataconnection
        clsDataConnection DB = new clsDataConnection();
        //execute the stored procedure to get the list of data
        DB.Execute("sproc_tblCustomerNo_SelectAll");
        //get the count of records
        Int32 RecordCount = DB.Count;
        //set up the index for the loop
        Int32 Index = 0;
        //while there are records to process 
        while (Index < RecordCount)
        {
            //create a new instance of the CustomerNo class
            clsCustomerNo ACustomerNo = new clsCustomerNo();
            //get the CustomerNo name
            ACustomerNo.CustomerNo = DB.DataTable.Rows[Index]["CustomerNo"].ToString();
            //get the primary key
            ACustomerNo.CustomerNo = Convert.ToInt32(DB.DataTable.Rows[Index]["CustomerNoNo"]);
            //add the CustomerNo to the private data member
            mAllCustomerNos.Add(ACustomerNo);
            //increment the index
            Index++;
        }
    }
    internal class mAllCustomerNos
    {
        internal static void Add(clsCustomerNo aCustomerNo)
        {
            throw new NotImplementedException();
        }
    }
}
