﻿using System;
using System.Collections.Generic;

namespace ClassLibrary
{
    public class clsModelCollection
    {
        public int Count { get; set; }
        public List<clsModel> AllModels { get; set; }
    }

    //public constructor for the class
    public clsModelCollection()
    {
        clsModel AModel = new clsModel();
        AModel.Model = "11";
        mAllModels.Add(AModel);
        AModel = new clsModel();
        AModel.Model = "Galaxy";
        mAllModels.Add(AModel);
    }

    //public constructor for the class
    public clsModelCollection()
    {
        //create and instance of the dataconnection
        clsDataConnection DB = new clsDataConnection();
        //execute the stored procedure to get the list of data
        DB.Execute("sproc_tblModel_SelectAll");
        //get the count of records
        Int32 RecordCount = DB.Count;
        //set up the index for the loop
        Int32 Index = 0;
        //while there are records to process 
        while (Index < RecordCount)
        {
            //create a new instance of the Model class
            clsModel AModel = new clsModel();
            //get the Model name
            AModel.Model = DB.DataTable.Rows[Index]["Model"].ToString();
            //get the primary key
            AModel.ModelNo = Convert.ToInt32(DB.DataTable.Rows[Index]["ModelNo"]);
            //add the Model to the private data member
            mAllModels.Add(AModel);
            //increment the index
            Index++;
        }
    }

    internal class mAllModels
    {
        internal static void Add(clsModel aModel)
        {
            throw new NotImplementedException();
        }
    }
}
