﻿using System;

namespace ClassLibrary
{
    internal class clsCustomerNo
    {
        public clsCustomerNo()
        { }
            public string CustomerNo { get; internal set; }

            internal string Valid(string someCustomerNo)
            {
                throw new NotImplementedException();
            }

            internal int Valid(int someCustomerNo)
            {
                throw new NotImplementedException();
            }
    }
}