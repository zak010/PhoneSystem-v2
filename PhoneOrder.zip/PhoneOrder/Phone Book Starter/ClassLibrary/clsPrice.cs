﻿using System;

namespace ClassLibrary
{
    internal class clsPrice
    {
        public int PriceNo { get; internal set; }
        public string Price { get; internal set; }

        internal bool Find(int orderNo)
        {
            throw new NotImplementedException();
        }
    }
}