﻿using System;
using System.Collections.Generic;

namespace ClassLibrary
{
    public class clsOrderCollection
    {
        public clsOrder ThisOrder { get; set; }
        //private data member for the list
        List<clsOrder> mOrderList = new List<clsOrder>();
        //public property for the address list
        public List<clsOrder> OrderList
        {
            get
            {
                //return the private data
                return mOrderList;
            }
            set
            {
                //set the private data
                mOrderList = value;
            }
        }

        //public property for count
        public int Count
        {
            get
            {
                //return the count of the list
                return mOrderList.Count;
            }
            set
            {
                //I'll worry about this later
            }
        }

        public void Add()
        {
            throw new NotImplementedException();
        }

        public void Delete()
        {
            throw new NotImplementedException();
        }

        public void Update()
        {
            throw new NotImplementedException();
        }

        public void ReportByBrand(string v)
        {
            throw new NotImplementedException();
        }
    }

    //constructor for the class
    public clsOrderCollection()
    {
        //object for the data connection
        clsDataConnection DB = new clsDataConnection();
        //execute the stored procedure
        DB.Execute("sproc_tblOrder_SelectAll");
        //populate the array list with the data table
        PopulateArray(DB);
        //var for the index
        Int32 Index = 0;
        //var to store the record count
        Int32 RecordCount = 0;
        //object for the data connection
        clsDataConnection DB = new clsDataConnection();
        //execute the stored procedure
        DB.Execute("sproc_tblOrder_SelectAll");
        //get the count of records
        RecordCount = DB.Count;
        //while there are records to process
        while (Index < RecordCount)
        {
            //create a blank Order
            clsOrder AnOrder = new clsOrder();
            //read in the fields from the current record
            AnOrder.Active = Convert.ToBoolean(DB.DataTable.Rows[Index]["Active"]);
            AnOrder.OrderNo = Convert.ToInt32(DB.DataTable.Rows[Index]["OrderNo"]);
            AnOrder.CustomerNo = Convert.ToString(DB.DataTable.Rows[Index]["CustomerNo"]);
            AnOrder.DateAdded = Convert.ToDateTime(DB.DataTable.Rows[Index]["DateAdded"]);
            AnOrder.Brand = Convert.ToString(DB.DataTable.Rows[Index]["Brand"]);
            AnOrder.Model = Convert.ToString(DB.DataTable.Rows[Index]["Model"]);
            AnOrder.Manufacturer = Convert.ToString(DB.DataTable.Rows[Index]["Manufacturer"]);
            AnOrder.Price = Convert.ToString(DB.DataTable.Rows[Index]["Price"]);
            //add the record to the private data member
            mOrderList.Add(AnOrder);
            //point at the next record
            Index++;
        }
    }

    internal class mOrderList
    {
        internal static void Add(clsOrder anOrder)
        {
            throw new NotImplementedException();
        }

        public void Add(global::clsOrder anOrder)
        {
            throw new NotImplementedException();
        }
    }

    public class clsOrderCollection
    {
        //private data member for the list
        List<clsOrder> mOrderList = new List<clsOrder>();
        //private data member thisOrder
        clsOrder mThisOrder = new clsOrder();
        //public property for ThisOrder
        public clsOrder ThisOrder
        {
            get
            {
                //return the private data
                return mThisOrder;
            }
            set
            {
                //set the private data
                mThisOrder = value;
            }
        }
    }
    public void ReportByBrand(string Brand)
    {
        //filters the records based on a full or partial brand
        //connect to the database
        clsDataConnection DB = new clsDataConnection();
        //send the Brand parameter to the database
        DB.AddParameter("@Brand", Brand);
        //execute the stored procedure
        DB.Execute("sproc_tblOrder_FilterByBrand");
        //populate the array list with the data table
        PopulateArray(DB);
    }
}